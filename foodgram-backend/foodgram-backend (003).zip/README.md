# FoodGram Backend

Node.js + Express + MongoDB backend for FoodGram app.